#include <Adafruit_NeoPixel.h>

#define PIN 4
#define NUM_LEDS 38
#define arrayLength 12

Adafruit_NeoPixel strip = Adafruit_NeoPixel(NUM_LEDS, PIN, NEO_GRB + NEO_KHZ800);

uint32_t BLACK = strip.Color(0, 0, 0);
uint32_t RED = strip.Color(255, 0, 0);
uint32_t YELLOW = strip.Color(255, 185, 0);
uint32_t ORANGE = strip.Color(255, 100, 0);

int innerMostRing[arrayLength] = {21,22,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1};
int innerMiddleRing[arrayLength] = {13,14,15,20,23,28,29,30,-1,-1,-1,-1};
int outerMiddleRing[arrayLength] = {7,8,9,12,16,19,24,27,31,34,35,36};
int outerMostRing[arrayLength] = {6,10,11,17,18,25,26,32,33,37,-1,-1};

int turnOnArray(int Array[10], uint32_t color){
  for(int i = 0; i < 10 && Array[i] != -1; i++){
    strip.setPixelColor(Array[i], color);
    strip.show();
  }
}

void off(){
  for(int i = 0; i < NUM_LEDS; i++){
    strip.setPixelColor(i, BLACK);
    strip.show();
  }
}

void exploded(){
  strip.begin();
  strip.show();

  strip.setPixelColor(0,RED);
  strip.show();
  delay(250);
  strip.setPixelColor(0,ORANGE);
  strip.setPixelColor(1,RED);
  strip.show();
  delay(250);
  strip.setPixelColor(0,YELLOW);
  strip.setPixelColor(1,ORANGE);
  strip.setPixelColor(2,RED);
  strip.show();
  delay(250);
  strip.setPixelColor(0,BLACK);
  strip.setPixelColor(1,YELLOW);
  strip.setPixelColor(2,ORANGE);
  strip.setPixelColor(3,RED);
  strip.show();
  delay(250);
  
  strip.setPixelColor(1,BLACK);
  strip.setPixelColor(2,YELLOW);
  strip.setPixelColor(3,ORANGE);
  strip.setPixelColor(4,RED);
  strip.show();
  delay(250);
  
  strip.setPixelColor(2,BLACK);
  strip.setPixelColor(3,YELLOW);
  strip.setPixelColor(4,ORANGE);
  strip.setPixelColor(5,RED);
  strip.show();
  delay(250);
  
  strip.setPixelColor(3,BLACK);
  strip.setPixelColor(4,YELLOW);
  strip.setPixelColor(5,ORANGE);
  strip.setPixelColor(8,RED);
  strip.show();
  delay(250);
  
  strip.setPixelColor(4,BLACK);
  strip.setPixelColor(5,YELLOW);
  strip.setPixelColor(8,ORANGE);
  strip.setPixelColor(14,RED);
  delay(250);
  
  strip.setPixelColor(5,BLACK);
  strip.setPixelColor(8,YELLOW);
  strip.setPixelColor(14,ORANGE);
  strip.setPixelColor(21,RED);
  strip.setPixelColor(22,RED);
  strip.show();
  delay(250);
  
  off();
  
  turnOnArray(innerMostRing, RED);
  delay(125);
  
  turnOnArray(innerMostRing, ORANGE);
  turnOnArray(innerMiddleRing, RED);
  delay(500);
  
  turnOnArray(innerMostRing, YELLOW);
  turnOnArray(innerMiddleRing, ORANGE);
  turnOnArray(outerMiddleRing, RED);
  delay(500);
  
  turnOnArray(innerMiddleRing, YELLOW);
  turnOnArray(outerMiddleRing, ORANGE);
  turnOnArray(outerMostRing, RED);
  delay(500);

}
